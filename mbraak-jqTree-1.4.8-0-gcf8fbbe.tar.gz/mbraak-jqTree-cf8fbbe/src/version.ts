const version = "1.4.8";

export default version;
