---
title: animationSpeed
name: options-animationspeed
---

Determine the speed of the slide animation. The value can be a number in millseconds, or a string like 'slow' or 'fast'. The default is 'fast'.

