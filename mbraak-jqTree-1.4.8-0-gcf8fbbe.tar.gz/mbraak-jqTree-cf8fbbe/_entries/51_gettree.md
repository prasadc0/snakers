---
title: getTree
name: functions-gettree
---

**function getTree();**

Get the root node of the tree.

{% highlight js %}
var tree_data = $('#tree1').tree('getTree');
{% endhighlight %}
