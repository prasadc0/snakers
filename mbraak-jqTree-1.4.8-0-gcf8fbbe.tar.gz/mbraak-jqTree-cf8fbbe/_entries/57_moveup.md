---
title: moveUp
name: functions-moveup
---

**function moveUp()**

Select the previous node. This does the same as the *up* key.