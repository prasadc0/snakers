---
title: destroy
name: functions-destroy
---

**function destroy();**

Destroy the tree. This removes the dom elements and event bindings.

{% highlight js %}
$('#tree1').tree('destroy');
{% endhighlight %}
