---
title: toggle
name: functions-toggle
---

**function toggle(node);**

**function toggle(node, slide);**

* slide: true / false

Open or close the tree node.
