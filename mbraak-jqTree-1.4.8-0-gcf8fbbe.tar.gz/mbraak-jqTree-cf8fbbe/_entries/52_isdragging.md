---
title: isDragging
name: functions-isdragging
---

**function isDragging();**

Is currently a node being dragged for drag-and-drop? Returns `True` or `False`.

{% highlight js %}
const is_dragging = $('#tree1').tree('isDragging');
{% endhighlight %}
