---
title: autoEscape
name: options-autoescape
---

Determine if text is autoescaped. The default is true.
