---
title: Tree options
name: tree-options
section: true
---

