---
title: Multiple selection
name: multiple-selection
section: true
---

Jqtree has some functions that can help you to implement multiple selection. See [Example 8 - multiple select](examples/08_multiple_select).

In order for multiple selection to work, you must give the nodes an id.
